package Controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import javax.swing.JTextField;

/**
 * A KeyAdapter implementation for handling key events in a product key input field.
 * It allows any combination of letters and numbers, with the restriction that symbols
 * are only allowed as hyphens ('-').
 * 
 * Example of a valid product key: R177A-2657017-APT
 * 
 * @author Hp
 */
public class ProductKeyTextFieldKeyListener extends KeyAdapter {

    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();

        // Allow letters, digits, and hyphen, while restricting other symbols
        if (!Character.isLetterOrDigit(c) && c != '-') {
            e.consume(); // Ignore the key event
        }

        JTextField textField = (JTextField) e.getSource();
        String text = textField.getText();

        // Limit the input to a reasonable length (adjust as needed)
        if (text.length() >= 20) { // Adjust the length as needed
            e.consume(); // Ignore the key event
        }
    }
}
