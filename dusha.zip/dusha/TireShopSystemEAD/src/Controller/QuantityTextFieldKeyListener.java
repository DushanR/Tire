package Controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import javax.swing.JTextField;

/**
 * A KeyAdapter implementation for handling key events in a quantity input field.
 * It allows only numeric input.
 * 
 * @author Hp
 */
public class QuantityTextFieldKeyListener extends KeyAdapter {

    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();

        // Allow only digits
        if (!Character.isDigit(c)) {
            e.consume(); // Ignore the key event
        }

        JTextField textField = (JTextField) e.getSource();
        String text = textField.getText();

        // Limit the input to a reasonable length (adjust as needed)
        if (text.length() >= 10) { // Adjust the length as needed
            e.consume(); // Ignore the key event
        }
    }
}
